wx version of pattern editor made by: https://www.reddit.com/user/blueSGL/
Original post: https://www.reddit.com/r/SP404/comments/1r9jfhw/pattern_editor_script_for_sp404mk2_alter/