import wx
import wx.grid
import struct

# --- Constants ---
EVENT_SIZE = 8
FOOTER_SIZE = 16
PAD_START_OFFSET = 47
PADS_PER_BANK = 16
TICKS_PER_QUARTER = 480
PITCH_ROOT = 141

BANKS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
TIME_SIG_MAP = {
    0: "4/4", 1: "3/4", 2: "2/4", 3: "1/4",
    4: "5/4", 5: "6/4", 6: "7/4"
}

# --- Motion opcode definitions (ground truth from your dumps) ---
FX_META_OP = 0x13   # paired/meta
FX_SEL_OP = 0x53    # effect select / front button press
CTRL_OPS = {        # knob automation
    0x10: "CTRL1",
    0x11: "CTRL2",
    0x12: "CTRL3",
}

# --- Effect ID mapping (data1 byte for opcode 0x53) ---
FX_ID_MAP = {
    # Front-panel assignable FX buttons (recorded as button presses)
    0x01: "BTN: Filter+Drive (assignable)",
    0x02: "BTN: Resonator (assignable)",
    0x03: "BTN: Delay (assignable)",
    0x04: "BTN: Isolator (assignable)",
    0x05: "BTN: DJFX Looper (assignable)",

    # MFX list (recorded as actual effects)
    0x06: "MFX: Scatter",
    0x07: "MFX: Downer",
    0x08: "MFX: Ha-Dou",
    0x09: "MFX: Ko-Da-Ma",
    0x0A: "MFX: Zan-Zou",
    0x0B: "MFX: To-Gu-Ro",
    0x0C: "MFX: SBF",
    0x0D: "MFX: Stopper",
    0x0E: "MFX: Tape Echo",
    0x0F: "MFX: TimeCtrlDly",
    0x10: "MFX: Super Filter",
    0x11: "MFX: WrmSaturator",
    0x12: "MFX: 303 VinylSim",
    0x13: "MFX: 404 VinylSim",
    0x14: "MFX: Cassette Sim",
    0x15: "MFX: Lo-fi",
    0x16: "MFX: Reverb",
    0x17: "MFX: Chorus",
    0x18: "MFX: JUNO Chorus",
    0x19: "MFX: Flanger",
    0x1A: "MFX: Phaser",
    0x1B: "MFX: Wah",
    0x1C: "MFX: Slicer",
    0x1D: "MFX: Tremolo/Pan",
    0x1E: "MFX: Chromatic PS",
    0x1F: "MFX: Hyper-Reso",
    0x20: "MFX: Ring Mod",
    0x21: "MFX: Crusher",
    0x22: "MFX: Overdrive",
    0x23: "MFX: Distortion",
    0x24: "MFX: Equalizer",
    0x25: "MFX: Compressor",
    0x26: "MFX: SX Reverb",
    0x27: "MFX: SX Delay",
    0x28: "MFX: Cloud Delay",
    0x29: "MFX: Back Spin",
    0x2A: "MFX: DJFX Delay",
    0x2B: "MFX: Filter+Drive",
    0x2C: "MFX: Resonator",
    0x2D: "MFX: Sync Delay",
    0x2E: "MFX: Isolator",
    0x2F: "MFX: DJFX Looper",

    # (not valid selections; kept for reference/debug)
    0x7F: "META: FX paired/state (0x13, data1=0x7F)",
    0x00: "META: FX off/clear? (0x13, data1=0x00)",
}

# Only allow real selectable IDs in the dropdown (avoid 0x00/0x7F)
FX_SELECT_MAP = {k: v for k, v in FX_ID_MAP.items() if 0x01 <= k <= 0x2F}


class EffectSelectorEditor(wx.grid.GridCellChoiceEditor):
    def __init__(self):
        choices = [f"{k:02X} - {v}" for k, v in FX_SELECT_MAP.items()]
        choices.sort()
        super().__init__(choices)


class SP404SoundDesigner(wx.Frame):
    def __init__(self):
        super().__init__(parent=None, title="SP-404MKII Sound Designer (Effect Sequencer)")
        self.raw_data = bytearray()
        self.events = []

        self.InitUI()
        self.Centre()
        self.SetSize((1300, 900))

    def InitUI(self):
        panel = wx.Panel(self)
        main_sizer = wx.BoxSizer(wx.VERTICAL)

        # Toolbar
        toolbar = wx.BoxSizer(wx.HORIZONTAL)
        btn_load = wx.Button(panel, label="Load Pattern")
        btn_save = wx.Button(panel, label="Save Changes")
        self.lbl_meta = wx.StaticText(panel, label="No File Loaded")

        btn_load.Bind(wx.EVT_BUTTON, self.OnLoad)
        btn_save.Bind(wx.EVT_BUTTON, self.OnSave)

        toolbar.Add(btn_load, 0, wx.ALL, 5)
        toolbar.Add(btn_save, 0, wx.ALL, 5)
        toolbar.Add(self.lbl_meta, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)
        main_sizer.Add(toolbar, 0, wx.EXPAND)

        # Splitter
        splitter = wx.SplitterWindow(panel)

        # --- NOTE GRID ---
        pnl_notes = wx.Panel(splitter)
        sz_notes = wx.BoxSizer(wx.VERTICAL)
        sz_notes.Add(wx.StaticText(pnl_notes, label="NOTES"), 0, wx.ALL, 5)

        self.grid_notes = wx.grid.Grid(pnl_notes)
        self.grid_notes.CreateGrid(0, 6)
        self.grid_notes.SetColLabelValue(0, "Time")
        self.grid_notes.SetColLabelValue(1, "Bank")
        self.grid_notes.SetColLabelValue(2, "Pad")
        self.grid_notes.SetColLabelValue(3, "Vel")
        self.grid_notes.SetColLabelValue(4, "Pitch")
        self.grid_notes.SetColLabelValue(5, "Flags")
        self.grid_notes.SetSelectionMode(wx.grid.Grid.GridSelectRows)

        sz_notes.Add(self.grid_notes, 1, wx.EXPAND)
        pnl_notes.SetSizer(sz_notes)

        # --- MOTION GRID ---
        pnl_motion = wx.Panel(splitter)
        sz_motion = wx.BoxSizer(wx.VERTICAL)
        sz_motion.Add(
            wx.StaticText(pnl_motion, label="MOTION (FX uses dropdown; CTRL values are numeric)"),
            0, wx.ALL, 5
        )

        self.grid_motion = wx.grid.Grid(pnl_motion)
        self.grid_motion.CreateGrid(0, 5)
        self.grid_motion.SetColLabelValue(0, "Time")
        self.grid_motion.SetColLabelValue(1, "Bus")
        self.grid_motion.SetColLabelValue(2, "Type")
        self.grid_motion.SetColLabelValue(3, "Effect / Param")
        self.grid_motion.SetColLabelValue(4, "Value")
        self.grid_motion.SetColSize(3, 280)

        sz_motion.Add(self.grid_motion, 1, wx.EXPAND)
        pnl_motion.SetSizer(sz_motion)

        splitter.SplitVertically(pnl_notes, pnl_motion)
        splitter.SetSashGravity(0.4)

        main_sizer.Add(splitter, 1, wx.EXPAND | wx.ALL, 5)
        panel.SetSizer(main_sizer)

    def TicksToTime(self, total_ticks: int) -> str:
        bar = (total_ticks // (TICKS_PER_QUARTER * 4)) + 1
        rem = total_ticks % (TICKS_PER_QUARTER * 4)
        beat = (rem // TICKS_PER_QUARTER) + 1
        tick = rem % TICKS_PER_QUARTER
        return f"{bar}:{beat}:{tick:03d}"

    def OnLoad(self, event):
        with wx.FileDialog(
            self,
            "Open Pattern",
            wildcard="BIN files (*.BIN)|*.BIN",
            style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST
        ) as dlg:
            if dlg.ShowModal() == wx.ID_CANCEL:
                return
            path = dlg.GetPath()

        with open(path, "rb") as f:
            self.raw_data = bytearray(f.read())

        self.ParseData()
        self.RefreshGrids()

    def _motion_key(self, m):
        # Key used to match FX_META(0x13) with FX_SEL(0x53) even if CTRL events appear between.
        # Observed stable in your dumps:
        #   - bus_flags (includes bus bit + extra flags like 0x40)
        #   - flags2 (often 0x00 or 0xFF)
        #   - t_field = (chunk[4] << 8) | chunk[7]
        return (m["bus_flags"], m["flags2"], m["t_field"])

    def BuildMotionEvents(self, motion_raw):
        """
        Converts raw 0x8E motion events into artist-meaningful rows:
          - FX Change rows: show only the FX_SEL(0x53) but allow pairing with FX_META(0x13)
          - CTRL rows: CTRL1/2/3 with editable value
        """
        out = []
        pending_meta = {}  # key -> True (we don't need its offset for editing)

        for m in motion_raw:
            op = m["opcode"]

            if op == FX_META_OP:
                pending_meta[self._motion_key(m)] = True
                continue

            if op == FX_SEL_OP:
                fx_id = m["data1"]
                fx_name = FX_ID_MAP.get(fx_id, f"ID {fx_id:02X}")

                paired = pending_meta.pop(self._motion_key(m), None) is not None
                type_str = "FX Change" if paired else "FX Change (unpaired)"

                out.append({
                    "type": "MOTION",
                    "kind": "FX",
                    "tick": m["tick"],
                    "bus": m["bus"],
                    "type_str": type_str,
                    "id_hex": f"{fx_id:02X}",
                    "effect_name": fx_name,
                    "offset_id": m["offset"],   # write FX id to this event at +6
                })
                continue

            if op in CTRL_OPS:
                out.append({
                    "type": "MOTION",
                    "kind": "CTRL",
                    "tick": m["tick"],
                    "bus": m["bus"],
                    "type_str": CTRL_OPS[op],
                    "ctrl_op": op,
                    "value": m["data1"],         # knob value is byte6 (0..127)
                    "offset_val": m["offset"],   # write knob value to this event at +6
                    "flags2": m["flags2"],
                    "bus_flags": m["bus_flags"],
                })
                continue

            # ignore other motion opcodes for now

        return out

    def ParseData(self):
        self.events = []
        body_len = len(self.raw_data) - FOOTER_SIZE
        current_tick = 0

        footer = self.raw_data[-FOOTER_SIZE:]
        bar_count = struct.unpack("<I", footer[8:12])[0]
        ts_idx = footer[12]
        self.lbl_meta.SetLabel(f"Bars: {bar_count} | TS: {TIME_SIG_MAP.get(ts_idx, '?')}")

        notes = []
        motion_raw = []

        for i in range(0, body_len, EVENT_SIZE):
            chunk = self.raw_data[i:i + EVENT_SIZE]
            delta = chunk[0]
            current_tick += delta

            byte1 = chunk[1]

            if byte1 == 0x8E:
                bus_flags = chunk[2]
                flags2 = chunk[3]
                opcode = chunk[5]
                data1 = chunk[6]
                data2 = chunk[7]

                bus_name = "BUS 2" if (bus_flags & 0x01) else "BUS 1"

                # Observed time-like field used for matching (from your dumps)
                t_field = (chunk[4] << 8) | data2

                motion_raw.append({
                    "tick": current_tick,
                    "offset": i,
                    "bus": bus_name,
                    "bus_flags": bus_flags,
                    "flags2": flags2,
                    "opcode": opcode,
                    "data1": data1,
                    "data2": data2,
                    "t_field": t_field,
                })
                continue

            if byte1 >= 128:
                continue

            # Note event
            flag = chunk[2]
            bank, pad = self.DecodePad(byte1, flag)
            if bank is not None:
                notes.append({
                    "type": "NOTE",
                    "tick": current_tick,
                    "offset": i,
                    "bank": bank,
                    "pad": pad,
                    "vel": chunk[4],
                    "pitch": chunk[3],
                    "flag": flag,
                })

        motions = self.BuildMotionEvents(motion_raw)
        self.events = notes + motions

    def DecodePad(self, note, flag):
        if note < PAD_START_OFFSET:
            return None, None
        norm = note - PAD_START_OFFSET
        base_bank = norm // PADS_PER_BANK
        pad = norm % PADS_PER_BANK
        if base_bank > 4:
            return None, None
        group_fj = (flag & 1) == 1
        bank = base_bank + (5 if group_fj else 0)
        return bank, pad

    def _reset_grid(self, grid: wx.grid.Grid):
        rows = grid.GetNumberRows()
        if rows:
            grid.DeleteRows(0, rows)

    def RefreshGrids(self):
        self._reset_grid(self.grid_notes)
        self._reset_grid(self.grid_motion)

        notes = [e for e in self.events if e["type"] == "NOTE"]
        motions = [e for e in self.events if e["type"] == "MOTION"]

        self.grid_notes.AppendRows(len(notes))
        self.grid_motion.AppendRows(len(motions))

        for row, n in enumerate(notes):
            self.grid_notes.SetCellValue(row, 0, self.TicksToTime(n["tick"]))
            self.grid_notes.SetCellValue(row, 1, BANKS[n["bank"]])
            self.grid_notes.SetCellValue(row, 2, str(n["pad"] + 1))
            self.grid_notes.SetCellValue(row, 3, str(n["vel"]))
            p = "PAD" if n["pitch"] == 0 else f"{n['pitch'] - PITCH_ROOT:+d}"
            self.grid_notes.SetCellValue(row, 4, p)

            flags = []
            if n["flag"] & 0x40:
                flags.append("GATE")
            if n["flag"] & 1:
                flags.append("F-J")
            self.grid_notes.SetCellValue(row, 5, ",".join(flags))

        for row, m in enumerate(motions):
            self.grid_motion.SetCellValue(row, 0, self.TicksToTime(m["tick"]))
            self.grid_motion.SetCellValue(row, 1, m["bus"])
            self.grid_motion.SetCellValue(row, 2, m["type_str"])

            if m["kind"] == "FX":
                display = f"{m['id_hex']} - {m['effect_name']}"
                self.grid_motion.SetCellValue(row, 3, display)
                self.grid_motion.SetCellValue(row, 4, "")

                # FX rows: dropdown editor on column 3 only
                self.grid_motion.SetCellEditor(row, 3, EffectSelectorEditor())
                self.grid_motion.SetReadOnly(row, 3, False)
                self.grid_motion.SetReadOnly(row, 4, True)

            elif m["kind"] == "CTRL":
                # CTRL rows: column 4 is numeric value (0..127), column 3 is label
                self.grid_motion.SetCellValue(row, 3, m["type_str"])
                self.grid_motion.SetCellValue(row, 4, str(m["value"]))

                self.grid_motion.SetReadOnly(row, 3, True)
                self.grid_motion.SetReadOnly(row, 4, False)

            else:
                # Shouldn't happen, but keep safe defaults
                self.grid_motion.SetCellValue(row, 3, "")
                self.grid_motion.SetCellValue(row, 4, "")
                self.grid_motion.SetReadOnly(row, 3, True)
                self.grid_motion.SetReadOnly(row, 4, True)

    def OnSave(self, event):
        motion_rows = self.grid_motion.GetNumberRows()
        motion_events = [e for e in self.events if e["type"] == "MOTION"]

        for row in range(motion_rows):
            ev = motion_events[row]
            try:
                if ev["kind"] == "FX":
                    cell_val = self.grid_motion.GetCellValue(row, 3)  # "0E - MFX: Tape Echo"
                    if " - " in cell_val:
                        hex_id = cell_val.split(" - ")[0].strip()
                        int_id = int(hex_id, 16)

                        off = ev["offset_id"]
                        self.raw_data[off + 6] = int_id  # FX id is byte6

                elif ev["kind"] == "CTRL":
                    new_val = int(self.grid_motion.GetCellValue(row, 4))
                    new_val = max(0, min(127, new_val))

                    off = ev["offset_val"]
                    self.raw_data[off + 6] = new_val  # CTRL value is byte6

                # IMPORTANT: do NOT blindly edit byte7 anymore (it is not "the value" for knobs,
                # and for many motion events it participates in timing/keys)

            except:
                pass

        with wx.FileDialog(
            self,
            "Save Pattern",
            wildcard="BIN files (*.BIN)|*.BIN",
            style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT
        ) as dlg:
            if dlg.ShowModal() == wx.ID_OK:
                with open(dlg.GetPath(), "wb") as f:
                    f.write(self.raw_data)
                wx.MessageBox("File saved!", "Success")


if __name__ == "__main__":
    app = wx.App()
    frame = SP404SoundDesigner()
    frame.Show()
    app.MainLoop()